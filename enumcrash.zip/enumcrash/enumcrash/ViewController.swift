//
//  ViewController.swift
//  enumcrash
//
//  Created by Dmitry Fedoseyev on 5/13/19.
//  Copyright © 2019 Dmitry Fedoseyev. All rights reserved.
//

import UIKit

enum DataLoadError: Error {
    case errorFetchingData(underlyingErrors: [Error])
    case other
}

class ViewController: UIViewController {

    var loadingErrors = [Error]()
    var failsCount:Int = 0
    var retriesAllowed:Int = 2

    override func viewDidLoad() {
        super.viewDidLoad()
        loadData(retriesAllowed: 2)
    }

    func loadData(retriesAllowed: Int) {
        loadingErrors.removeAll()
        DispatchQueue.main.async {
            self.loadingErrors.append(DataLoadError.other)
            self.notifyCompletion()
        }
    }

    private func notifyCompletion() {
        let success = loadingErrors.count == 0
        let error = (success ? nil : DataLoadError.errorFetchingData(underlyingErrors: loadingErrors))
        let shouldRetry = !success && failsCount < retriesAllowed
        guard !shouldRetry else {
            handleRetry(error: error)
            return }

        print("load success")
    }
    
    func handleRetry(error: Error?) {
        failsCount += 1
        loadData(retriesAllowed: retriesAllowed)
    }

}

